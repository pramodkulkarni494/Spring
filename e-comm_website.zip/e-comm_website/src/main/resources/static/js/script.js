const paymentStart = () => {
    console.log("payment started!!!");
};